<footer class="main-footer no-print">
  <div class="pull-right hidden-xs"><b>Template Version</b> 2.0</div>
</footer>
