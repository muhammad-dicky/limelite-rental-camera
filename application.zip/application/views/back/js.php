<!-- Jquery -->
<script src="<?php echo base_url('assets/plugins/')?>jquery/jquery-3.3.1.js"></script>
<!-- Bootstrap 3.3.2 JS -->
<script src="<?php echo base_url('assets/template/backend/')?>bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/template/backend/')?>dist/js/app.min.js" type="text/javascript"></script>
