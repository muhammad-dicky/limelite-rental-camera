<?php
$style_subkat='class="form-control" id="subkat_id"';
echo form_dropdown("subkat_id",$subkategori,'',$style_subkat);
?>
