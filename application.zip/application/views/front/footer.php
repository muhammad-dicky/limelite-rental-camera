  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <hr>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        
        <div class="col-xs-6" align="right"><a href="#top">Back to Top</a></div>
      </div>
    </div>
  </footer>
  </body>

  </html>