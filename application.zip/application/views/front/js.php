<!-- Bootstrap core JavaScript -->
<script src="<?php echo base_url('assets/template/frontend/') ?>vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url('assets/template/frontend/') ?>vendor/popper/popper.min.js"></script>
<script src="<?php echo base_url('assets/template/frontend/') ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Plugin JavaScript -->
<script src="<?php echo base_url('assets/template/frontend/') ?>vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="<?php echo base_url('assets/template/frontend/') ?>vendor/scrollreveal/scrollreveal.min.js"></script>
<script src="<?php echo base_url('assets/template/frontend/') ?>vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

<!-- Custom scripts for this template -->
<script src="<?php echo base_url('assets/template/frontend/') ?>js/creative.min.js"></script>
