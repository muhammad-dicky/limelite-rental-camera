<div class="bs-callout bs-callout-primary"><h4><i class="fa fa-search"></i> Find Us On</h4></div>
<div class="input-group">
  <button type="button" class="btn btn-sm btn-primary"  onclick=" window.open('https://web.facebook.com/JAKAL7.FUTSAL/','_blank')"><i class="fa fa-facebook"></i></button>&nbsp
  <button type="button" class="btn btn-sm btn-primary" onclick=" window.open('https://www.instagram.com/jakaltujufutsal/','_blank')"><i class="fa fa-instagram"></i></button>&nbsp
  <button type="button" class="btn btn-sm btn-primary" onclick=" window.open('https://twitter.com/Jakal7_Futsal/','_blank')"><i class="fa fa-twitter"></i></button>
</div>
