<div class="col-md-4">
  <?php $this->load->view('front/modul/mod_sosmed'); ?>
  <?php $this->load->view('front/modul/mod_facebook'); ?>
  <?php $this->load->view('front/modul/mod_event'); ?>
	<?php $this->load->view('front/modul/mod_kategori'); ?>
  <?php $this->load->view('front/modul/mod_cs'); ?>

</div>
